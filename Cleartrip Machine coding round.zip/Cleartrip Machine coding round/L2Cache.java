import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class L2Cache {
    private int capacity;
//    max capacity 20;
    private Map<String, List<Movie>> globalCache;
    private Map<String, Integer> frequency;

    public L2Cache(int capacity){
        this.capacity = capacity;
        this.globalCache = new HashMap<>();
        this.frequency = new HashMap<>();
    }
    public List<Movie> get(String searchKey){
        if(!globalCache.containsKey(searchKey)){
            return null;
        }
        frequency.put(searchKey,frequency.get(searchKey));
        return globalCache.get(searchKey);
    }

//           incom
    public void put(String searchKey, List<Movie> movies){
        if(globalCache.size()>= capacity){

        }
    }
    public void clear(){
        globalCache.clear();
    }
}
