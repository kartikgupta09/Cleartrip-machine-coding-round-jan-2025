public class User {
     int id;
     String name;
     String preferredGenre;

    public User(int id, String name, String preferredGenre){
        this.id = id;
        this.name = name;
        this.preferredGenre = preferredGenre;
    }

    public int getId(){
        return  id;
    }
    public String getName(){
        return name;
    }

    public String getPreferredGenre(){
        return preferredGenre;
    }
}


