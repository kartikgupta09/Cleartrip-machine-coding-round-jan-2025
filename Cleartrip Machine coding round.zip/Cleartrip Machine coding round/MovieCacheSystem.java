public class MovieCacheSystem {
    public static void main(String[] args) {
        MovieContentManager manager = new MovieContentManager();
        manager.addMovie(1, "Inception", "scific", 2010, 9.5);
        manager.addUser(1,"john", "action");
        manager.search(1, "title","inception");
        manager.seachMulti(1,"action",2008,8.0);
    }
}
