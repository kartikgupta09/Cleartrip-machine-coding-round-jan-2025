import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MovieContentManager {
    private Map<Integer, List<Movie>> movieStore;
    private Map<Integer, List<User>> userStore;
    private L1Cache l1Cache;
    private L2Cache l2Cache;

    public  MovieContentManager(){
        this.movieStore = new HashMap<>();
        this.userStore = new HashMap<>();
        this.l1Cache = new L1Cache(5);
        this.l2Cache = new L2Cache(20);
    }
    public void addMovie(int id, String title, String genre, int year, double rating){
        try {

            if(title == null || title.trim().isEmpty()){
                throw new IllegalArgumentException("Title cannot be empty");
            }
            if(year<0){
                throw new IllegalArgumentException("year cannot be negative");
            }
            int currentyear = 2025;
            if(year>currentyear){
                throw new IllegalArgumentException("year greater then curent year");
            }
            if(rating<0 || rating >10){
                throw new IllegalArgumentException("rating not in range");
            }
            if (movieStore.containsKey(id)) {
                throw new IllegalArgumentException("Duplicate id for Movie");
            }
            List<Movie> mm = new ArrayList<>();
            Movie m = new Movie(id, title, genre, year, rating);
            mm.add(m);
            movieStore.put(id, mm);

            System.out.println("Movie " + id + " and " + title + "added succesfully");
        } catch (IllegalArgumentException e) {
            System.out.println("Eroor "+ e.getMessage());
        }

    }
    public void addUser(int id, String name, String preferred_genre){

        try {
            if(name==null){
                throw new IllegalArgumentException("user cannot be null");
            }
            if(name.trim().isEmpty()){
                throw new IllegalArgumentException("user name cannot be empty");
            }
            if(preferred_genre==null || preferred_genre.trim().isEmpty()){
                throw new IllegalArgumentException("preferred genre cannot be empty");
            }
            if(userStore.containsKey(id)){
                throw new IllegalArgumentException("duplicate user id");
            }

            if (userStore.containsKey(id)) {
                if (movieStore.containsKey(id)) {
                    throw new IllegalArgumentException("Duplicate id for Movie");
                }
               userStore.put(id, new User(id, name, preferred_genre));
                System.out.println("User " + id + " and name " + name + "added succesfully");

            }

        }catch (IllegalArgumentException e){
            System.out.println("error" +":" + e.getMessage());
        }
    }

    public void search(int userId, String searchType, String searchValue){

        try {


            if (!userStore.containsKey(userId)) {
                System.out.println("Invalid use or user not present");
            }
            return;

            if(searchType == null || searchType.trim().isEmpty()){
                throw new IllegalArgumentException("search type cannot be null");

            }
            if(searchValue == null || searchValue.trim().isEmpty()){
                throw new IllegalArgumentException("search value cannot be null");

            }



            String searchKey = searchType + ":" + searchValue;

            List<Movie> result = l1Cache.get(userId, searchKey);

            if (result.isEmpty()) {
                System.out.println("not found result");
                return;
            }else{
                System.out.println("found in primary store ");
                l1Cache.put(userId, searchKey, result);
                l2Cache.put(searchKey,result);
            }



        }catch (IllegalArgumentException e){
            System.out.println("error"+":"+ e.getMessage());
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void seachMulti(int userId, String genre, int year, double minRating){
        try{
            if(!userStore.containsKey(userId)){
                System.out.println("error invalid userid");
            }
            if(genre == null || genre.trim().isEmpty()){
                System.out.println("genre cannot be null or is empty");
            }if(year<=0 || year>2025){
                System.out.println("invalid year");
            }
            if(minRating<0 || minRating>10){
                System.out.println(" rating out of range");
            }
            String searchKey = "MULTI : "+genre +":" + year +":" + minRating;

            if(getCacheName(userId,searchKey)) return;

            List<Movie> result  = new ArrayList<>();
            for(Movie movie: movieStore.values()){
                if(movie.getGenre().equalsIgnoreCase(genre) && movie.getReleaseyear() == year && movie.getRating()>=minRating){
                    result.add(movie);
                }
            }
            if (result.isEmpty()){
                System.out.println("no result found");
            }else{
                System.out.println(result+"found in primary store");
                l1Cache.put(userId,searchKey,result);
                l2Cache.put(searchKey,result);


            }
        }
        catch (IllegalArgumentException e){
            System.out.println("error"+":"+ e.getMessage());
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    boolean getCacheName (int userId, String searchKey){
        try {
            List<Movie> result = l1Cache.get(userId, searchKey);
            if (result!=null){
                System.out.println(result+ " found in l1 cache");
                return true;
            }
            result = l2Cache.get(searchKey);
            if (result!=null){
                System.out.println(result+ " found in l2 cache");

                l1Cache.put(userId, searchKey, result);
                return true;
            }


        }catch (Exception e){
            System.out.println("error while fetching from cahce" + e.getMessage());

        }
        return false;
    }

}

//store movie, store user, l1 cache, l2 cache
//ADD_MOVIE <id> <title> <genre> <year> <rating>
//ADD_USER <id> <name> <preferred_genre>