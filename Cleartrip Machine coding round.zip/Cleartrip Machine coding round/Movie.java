public class Movie {
    private int id;
    private String title;
    private String genre;
    private int releaseyear;
    private double rating;

    public Movie(int id, String title, String genre, int releaseyear, double rating){
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.releaseyear = releaseyear;
        this.rating = rating;
    }
    public int getId(){
        return id;
    }
    public String getTitle(){
        return title;
    }
    public String getGenre(){
        return  genre;
    }
    public int getReleaseyear(){
        return releaseyear;
    }
    public double getRating(){
        return rating;
    }
}



//Movie ID (unique)
//Title
//Genre
//Release Year
//Rating