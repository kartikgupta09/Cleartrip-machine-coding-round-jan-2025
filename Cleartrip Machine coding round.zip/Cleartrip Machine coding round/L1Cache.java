import java.util.*;

public class L1Cache {
    private final int capacity;
    private Map<Integer, LinkedHashMap<String, List<Movie>>> userCache;

    public L1Cache(int capacity){
        this.capacity = capacity;
        this.userCache = new HashMap<>();
    }
    public List<Movie> get(int userId, String seachKey){
        if(!userCache.containsKey(userId)){
            return null;
        }
        LinkedHashMap<String, List<Movie>> cache = userCache.get(userId);
        if(!cache.containsKey(seachKey)) return null;
        List<Movie> result = cache.remove(seachKey);
        cache.put(seachKey, result);
        return result;
    }
    public void put(int userId, String searchKey, List<Movie> movies){
        userCache.putIfAbsent(userId,new LinkedHashMap<>(capacity,0.75f,true));

        LinkedHashMap<String , List<Movie>> cache = userCache.get(userId);
        if(cache.size()>=capacity){
            Iterator<String> it = cache.keySet().iterator();
            it.next();
            it.remove();
        }
        cache.put(searchKey,movies);
    }
    public void clear(){
        userCache.clear();

    }
}





//L1: User-specific cache
//        Maximum 5 entries per user capacity
//        Implements LRU (Least Recently Used) eviction








